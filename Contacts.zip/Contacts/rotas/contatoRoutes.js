const express = require('express')
const router = express.Router()
const Contatos = require('../models/Contato')
const { mongo, default: mongoose } = require('mongoose')

// Rota para listar todos os contatos
router.get('/', async (req, res) => {
    const dados = await Contatos.find()
    res.status(200).json(dados)    
})

// Criar contatos
router.post('/', async (req, res) => {
    const dados = await Contatos.create(req.body)
    res.status(200).json(dados)
})

// Buscar por ID
router.get('/:id', async (req, res) => {
    if((mongoose.Types.ObjectId.isValid(req.params.id)) === false) {
        return res.status(400).json({ error: 'ID inválido' })
    }
    const dado = await Contatos.findById(req.params.id)
    if (!dado) {
        return res.status(404).json({ error: 'Contato não encontrado' })
    }
    res.status(200).json(dado)
})

//Atualizar por ID
router.put('/:id', async (req, res) => {
    const dado = await Contatos.findByIdAndUpdate(req.params.id, req.body, { new: true })
    if (!dado) {
        return res.status(404).json({ error: 'Contato não encontrado' })
    }
    res.status(200).json(dado)
})

// Deletar por ID
router.delete('/:id', async (req, res) => {
    const dado = await Contatos.findByIdAndDelete(req.params.id)
    if (!dado) {
        return res.status(404).json({ error: 'Contato não encontrado' })
    }
    res.status(200).json(dado)
})

module.exports = router