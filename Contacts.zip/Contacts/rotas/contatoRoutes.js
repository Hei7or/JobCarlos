const express = require('express') // Importando o módulo express para criar rotas
const router = express.Router() // Importando o módulo express para criar rotas
const Contatos = require('../models/Contato') // Importando o modelo Contatos para manipulação de dados
const { mongo, default: mongoose } = require('mongoose') // Importando o mongoose para validação de ID

// Rota para listar todos os contatos
router.get('/', async (req, res) => {
    const dados = await Contatos.find()
    
    if (dados.length > 0) {
        return res.status(200).json({ 
            message: 'Contatos encontrados com sucesso', //Retorno da mensagem de padronização 
            contatos: dados // Retorno dos dados encontrados
        }) 
    }
    res.status(404).json({ error: 'Nenhum contato encontrado' }) //Se não encontrar nenhum contato, retorna erro 404
})
    

// Criar contatos
router.post('/', async (req, res) => {
    const dados = await Contatos.create(req.body) // Cria um novo contato com os dados recebidos no corpo da requisição

    //if ("nome" in req === true || "email" in req === true|| "telefone" in req === true) {
    if (!req.body.nome || !req.body.email || !dados.telefone) { // Verifica se os campos obrigatórios estão preenchidos   
    return res.status(200).json({
            message: 'Contato criado com sucesso', // Retorno da mensagem de padronização
            contato: dados // Retorno do contato criado
        })
    }
})

// Buscar por ID
router.get('/:id', async (req, res) => {
    if((mongoose.Types.ObjectId.isValid(req.params.id)) === false) {  
        return res.status(400).json({ error: 'ID inválido' })  // Verifica se o ID é válido
    }
    const dado = await Contatos.findById(req.params.id)  // Busca o contato pelo ID fornecido
    if (!dado) {
        return res.status(404).json({ error: 'Contato não encontrado' }) // Se não encontrar o contato, retorna erro 404
    }
    res.status(200).json({ message: 'Contato encontrado com sucesso' }) && res.status(200).json(dado) // Retorna o contato encontrado com status 200
})

//Atualizar por ID
router.put('/:id', async (req, res) => {
    const dado = await Contatos.findByIdAndUpdate(req.params.id, req.body, { new: true }) // Atualiza o contato pelo ID fornecido com os dados recebidos no corpo da requisição
    if (!dado) {
        return res.status(404).json({ error: 'Contato não encontrado' }) // Se não encontrar o contato, retorna erro 404
    }
    res.status(200).json({ message: 'Contato atualizado com sucesso' }) && res.status(200).json(dado) // Retorna o contato atualizado com status 200
})

// Deletar por ID
router.delete('/:id', async (req, res) => {
    const dado = await Contatos.findByIdAndDelete(req.params.id) // Deleta o contato pelo ID fornecido
    if (!dado) {
        return res.status(404).json({ error: 'Contato não encontrado' }) // Se não encontrar o contato, retorna erro 404
    }
    res.status(200).json({ message: 'Contato deletado com sucesso' }) // Retorna a mensagem de sucesso e o contato deletado com status 200
    res.status(200).json(dado) 
})


module.exports = router 